<?php
require("view.php");

class MainAction extends DBConnect
{
    public function saveUserVisit($user_ip, $user_agent, $referral_source, $landing_page, $browser, $operating_system, $device_type, $screen_resolution, $language, $country, $city, $isp)
    {
        try {
            // Use IP-API to get additional information
            $api_url = "http://ip-api.com/json/{$user_ip}";
            $api_response = file_get_contents($api_url);

            if ($api_response === FALSE) {
                throw new Exception("Failed to fetch data from the IP-API.");
            }

            $api_data = json_decode($api_response, true);

            // Extract relevant data from the API response
            $country = $api_data['country'] ?? $country;
            $city = $api_data['city'] ?? $city;
            $isp = $api_data['isp'] ?? $isp;

            $pdo = $this->connect(); // Use the connect method from the parent class

            // Prepare SQL statement
            $stmt = $pdo->prepare("
                INSERT INTO user_visits 
                (user_ip, user_agent, referral_source, landing_page, browser, operating_system, device_type, screen_resolution, language, country, city, isp) 
                VALUES 
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            // Provide default values for optional parameters
            $referral_source = $referral_source ?? 'DefaultReferralSource';
            $browser = $browser ?? 'DefaultBrowser';
            // Add similar lines for other optional parameters

            // Bind parameters
            $stmt->bindParam(1, $user_ip);
            $stmt->bindParam(2, $user_agent);
            $stmt->bindParam(3, $referral_source);
            $stmt->bindParam(4, $landing_page);
            $stmt->bindParam(5, $browser);
            $stmt->bindParam(6, $operating_system);
            $stmt->bindParam(7, $device_type);
            $stmt->bindParam(8, $screen_resolution);
            $stmt->bindParam(9, $language);
            $stmt->bindParam(10, $country);
            $stmt->bindParam(11, $city);
            $stmt->bindParam(12, $isp);

            // Execute the statement
            $result = $stmt->execute();

            if ($result) {
                echo "Data inserted successfully!";
            } else {
                echo "Error inserting data: " . implode(" - ", $stmt->errorInfo());
            }

        } catch (Exception $e) {
            // Handle exceptions
            echo "Error: " . $e->getMessage();
        } catch (PDOException $e) {
            // Handle database connection errors
            die("Error: " . $e->getMessage());
        }
    }
}

// Example usage:
$user_ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$referral_source = $_GET['referral_source'] ?? null;  // Replace with your logic to get referral source
$landing_page = $_SERVER['REQUEST_URI'];
$browser = $_GET['browser'] ?? null;  // Replace with your logic to get browser
$operating_system = $_GET['operating_system'] ?? null;  // Replace with your logic to get operating system
$device_type = $_GET['device_type'] ?? null;  // Replace with your logic to get device type
$screen_resolution = $_GET['screen_resolution'] ?? null;  // Replace with your logic to get screen resolution
$language = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? null;  // Replace with your logic to get language
$country = $_GET['country'] ?? null;  // Replace with your logic to get country
$city = $_GET['city'] ?? null;  // Replace with your logic to get city
$isp = $_GET['isp'] ?? null;  // Replace with your logic to get ISP

if (isset($_GET['record_visit'])) {
    $mainAction = new MainAction();
    $mainAction->saveUserVisit($user_ip, $user_agent, $referral_source, $landing_page, $browser, $operating_system, $device_type, $screen_resolution, $language, $country, $city, $isp);
}
?>
