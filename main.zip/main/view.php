<?php
require("drive.php");
class MainView extends DBConnect
{
 public function recordUserVisit(){
    $con = parent::connect();

 }

}